The folder DNA_sequences contain the 3 DNA sequences used in FASTA format

The folder OOGGA_output contains the results from OOGGA under 3 different w_eff or 0 (suffix no_eff), 0.5 (suffix eff_0.5) and 1 (no suffix)

The folder splitset_output contains the results from splitset webserver

The folder splitset_output_evaluated_by_OOGGA_scoring contains files where splitset outputs were scored by OOGGA scoring method (described in manuscript methods section)

The file comparison (.xlsx and .csv) contains the comparison tables derived from the above outputs.

